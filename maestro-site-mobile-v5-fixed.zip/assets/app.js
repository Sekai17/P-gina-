
/* Maestro – JS moderno (ES2023), sin dependencias, accesible y performante. */
const $ = (sel, ctx=document) => ctx.querySelector(sel);
const $$ = (sel, ctx=document) => [...ctx.querySelectorAll(sel)];

const state = {
  theme: localStorage.getItem("theme") || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"),
  currency: localStorage.getItem("currency") || "ARS",  // ARS | USD
  service: "marketing", // pricing selector
  data: null
};

document.documentElement.setAttribute("data-theme", state.theme);

function fmtCurrency(value, currency) {
  try {
    return new Intl.NumberFormat("es-AR", { style:"currency", currency, maximumFractionDigits:0 }).format(value);
  } catch {
    return (currency === "USD" ? "US$" : "$") + value.toLocaleString("es-AR");
  }
}

async function loadData(){
  const res = await fetch("./assets/plans.json", { cache:"no-store" });
  state.data = await res.json();
  renderHeaderMeta();
  renderPricing();
  setupCalculator();
  renderExample();
}

function getExchangeRate(){
  return Number(state.data?.config?.usd_rate || 1500);
}

function priceToCurrency(priceARS){
  if(state.currency === "ARS") return priceARS;
  const rate = getExchangeRate();
  return Math.max(0, Math.round(priceARS / rate));
}

function renderHeaderMeta(){
  const brand = state.data.config.brand;
  const slogan = state.data.config.slogan;
  document.title = `${brand} · Servicios de Marketing & Secretaría`;
  const desc = "Servicios de Marketing Digital y Secretaría Administrativa con planes mensuales claros, contrato por 1–6 meses y registro obligatorio. Moneda ARS/USD.";
  $('meta[name="description"]').setAttribute("content", desc);
  $('meta[property="og:title"]').setAttribute("content", `${brand} – ${slogan}`);
  $('meta[property="og:description"]').setAttribute("content", desc);
  $("#brand-name").textContent = brand;
  $("#slogan").textContent = slogan;
  $("#whatsapp-link").href = `https://wa.me/${state.data.config.whatsapp}`;
  $("#email-link").href = `mailto:${state.data.config.email}`;
  $("#footer-email").textContent = state.data.config.email;
  $("#footer-addr").textContent = state.data.config.address;
  $("#contabilidad-estimada").textContent = state.data.config.contabilidad_estimada;
  $("#iva-text").textContent = state.data.config.iva_text;
}

function setTheme(next){
  const metaTheme = document.querySelector('meta[name="theme-color"]');
  if(metaTheme) metaTheme.setAttribute('content', next==='dark' ? '#0b0c0f' : '#ffffff');
  state.theme = next;
  localStorage.setItem("theme", next);
  document.documentElement.setAttribute("data-theme", next);
}
function toggleTheme(){ setTheme(state.theme === "dark" ? "light" : "dark"); }

function setCurrency(next){
  state.currency = next;
  localStorage.setItem("currency", next);
  renderPricing();
  updateCalculatorTotals();
}

function renderPricing(){
  const svcKey = state.service;
  const svc = state.data.services[svcKey];
  $("#service-current").textContent = svc.name;
  $$(".pricing .card").forEach(c => c.remove());

  const plans = ["gratis","basico","medio","pro"];
  const frag = document.createDocumentFragment();
  for(const key of plans){
    const p = svc.plans[key];
    const price = priceToCurrency(p.price_ars);
    const priceText = p.price_ars === 0 ? "Sin costo" : fmtCurrency(price, state.currency) + "/mes";
    const card = document.createElement("article");
    card.className = "card";
    card.innerHTML = `
      <h3>${p.label}</h3>
      <div class="price" aria-live="polite">${priceText}</div>
      <div class="kicker" id="iva-text">${state.data.config.iva_text}</div>
      <div class="kv">
        <div><strong>Incluye</strong><ul class="list">${p.includes.map(x=>`<li><span class="dot"></span><span>${x}</span></li>`).join("")}</ul></div>
        <div><strong>No incluye</strong><ul class="list">${p.not_includes.map(x=>`<li><span class="dot"></span><span>${x}</span></li>`).join("")}</ul></div>
      </div>
      <div class="kv">
        <div><strong>Límites</strong><ul class="list">${p.limits.map(x=>`<li><span class="dot"></span><span>${x}</span></li>`).join("")}</ul></div>
        <div><strong>Entregables</strong><ul class="list">${p.deliverables.map(x=>`<li><span class="dot"></span><span>${x}</span></li>`).join("")}</ul></div>
      </div>
      <p class="small muted"><strong>SLA:</strong> ${p.sla}. Ventana horaria: ${state.data.config.business_hours}.</p>
      <div class="actions">
        <button class="btn primary" data-action="calc" data-service="${svcKey}" data-plan="${key}">Calcular total y contratar</button>
      </div>
    `;
    frag.appendChild(card);
  }
  $(".pricing").appendChild(frag);
}

function bindPricingTabs(){
  $$(".tab[data-svc]").forEach(btn => {
    btn.addEventListener("click", () => {
      state.service = btn.dataset.svc;
      $$(".tab[data-svc]").forEach(b => b.setAttribute("aria-selected", String(b === btn)));
      renderPricing();
      // sync calculator
      $("#calc-service").value = state.service;
      syncCalcPlans();
      updateCalculatorTotals();
    });
  });
}

function setupToggles(){
  $("#theme-toggle").addEventListener("change", (e)=> setTheme(e.target.checked ? "dark" : "light"));
  $("#theme-toggle").checked = state.theme === "dark";

  $("#currency-ars").addEventListener("click", ()=> setCurrency("ARS"));
  $("#currency-usd").addEventListener("click", ()=> setCurrency("USD"));
  if(state.currency === "ARS"){ $("#currency-ars").setAttribute("aria-pressed","true"); }
  else { $("#currency-usd").setAttribute("aria-pressed","true"); }
}

function setupButtons(){
  document.body.addEventListener("click", (e)=>{
    const btn = e.target.closest("[data-action='calc']");
    if(btn){
      const svc = btn.dataset.service;
      const plan = btn.dataset.plan;
      $("#calc-service").value = svc;
      syncCalcPlans();
      $("#calc-plan").value = plan;
      document.getElementById("calc").scrollIntoView({ behavior:"smooth" });
      updateCalculatorTotals();
    }
  });
}

function syncCalcPlans(){
  const svcKey = $("#calc-service").value;
  const options = ["gratis","basico","medio","pro"]
    .map(k => `<option value="${k}">${state.data.services[svcKey].plans[k].label}</option>`)
    .join("");
  $("#calc-plan").innerHTML = options;
}

function setupCalculator(){
  syncCalcPlans();
  $("#calc-service").addEventListener("change", ()=>{ syncCalcPlans(); updateCalculatorTotals(); });
  $("#calc-plan").addEventListener("change", updateCalculatorTotals);
  $("#calc-months").addEventListener("input", (e)=>{
    const val = Math.max(1, Math.min(6, parseInt(e.target.value || "1", 10)));
    e.target.value = val;
    updateCalculatorTotals();
  });
  $("#calc-autorenew").addEventListener("change", updateCalculatorTotals);
  $("#calc-currency").addEventListener("change", (e)=>{
    setCurrency(e.target.value);
    // radio to buttons state
    $("#currency-ars").setAttribute("aria-pressed", state.currency==="ARS");
    $("#currency-usd").setAttribute("aria-pressed", state.currency==="USD");
  });
}

function updateCalculatorTotals(){
  const svcKey = $("#calc-service").value;
  const planKey = $("#calc-plan").value;
  const months = Number($("#calc-months").value || 1);
  const pARS = state.data.services[svcKey].plans[planKey].price_ars;
  const per = priceToCurrency(pARS);
  const total = per * months;
  const label = state.data.services[svcKey].plans[planKey].label;
  const svcName = state.data.services[svcKey].name;
  const curr = state.currency;
  const breakdown = `Plan ${label} de ${svcName}: ${fmtCurrency(per, curr)}/mes × ${months} meses = ${fmtCurrency(total, curr)}`;
  $("#calc-result").textContent = breakdown;
  const gratis = pARS === 0;
  $("#calc-continue").disabled = false; // still allow to continue to registro (gratis requiere registro)
  $("#calc-note").textContent = gratis ? "Alcance limitado. No se solicita pago." : "";
}

function renderExample(){
  // example for "Plan Medio de Marketing" for 3 months
  const pARS = state.data.services["marketing"].plans["medio"].price_ars;
  const per = priceToCurrency(pARS);
  const total = per * 3;
  $("#ex-medio-mkt").textContent = `Plan Medio de Marketing: ${fmtCurrency(per, state.currency)}/mes. Por 3 meses: ${fmtCurrency(total, state.currency)}.`;
}

function setupForms(){
  const form = $("#form-registro");
  form.addEventListener("submit", (e)=>{
    e.preventDefault();
    // honeypot
    if ($("#hp-company").value.trim() !== "") return alert("Error de validación.");
    if(!form.checkValidity()){
      form.reportValidity();
      return;
    }
    // mock "enviado"
    $("#form-ok").classList.remove("hidden");
    form.reset();
  });
}

function setupCookie(){
  const seen = localStorage.getItem("cookie_ok");
  if(!seen){
    $(".cookie").classList.add("show");
    $("#cookie-accept").addEventListener("click", ()=> {
      localStorage.setItem("cookie_ok", "1");
      $(".cookie").classList.remove("show");
    });
  }
}

function setupFaqLinks(){
  // Expand first FAQ by default
  const first = $(".faq details");
  if(first) first.open = true;
}

function injectSchema(){
  // Static JSON-LD for Organization & Services
  const brand = state.data.config.brand;
  const email = state.data.config.email;
  const ld = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": brand,
    "email": email,
    "url": location.origin,
    "address": state.data.config.address,
    "sameAs": []
  };
  const s = document.createElement("script");
  s.type = "application/ld+json";
  s.textContent = JSON.stringify(ld);
  document.head.appendChild(s);
}


function setupAnnounce(){
  const bar = document.querySelector(".announce");
  const closeBtn = document.querySelector("#announce-close");
  if(!bar) return;
  if(localStorage.getItem("announce_closed")==="1"){
    bar.style.display = "none";
  }
  if(closeBtn){
    closeBtn.addEventListener("click", ()=>{
      localStorage.setItem("announce_closed","1");
      bar.style.display = "none";
    });
  }
  try{
    const brand = (state && state.data && state.data.config && state.data.config.brand) || "Maestro";
    const el = document.querySelector("#announce-text");
    if(el) el.textContent = `${brand}: soluciones para todo (o casi todo) — Marketing, Secretaría y más.`;
  }catch{}
}



function setupMenu(){
  const btn = document.querySelector("#menu-btn");
  const nav = document.querySelector("nav");
  const links = document.querySelector("#nav-links");
  if(!btn || !nav || !links) return;
  btn.addEventListener("click", ()=>{
    const open = nav.getAttribute("data-open")==="true";
    nav.setAttribute("data-open", String(!open));
    btn.setAttribute("aria-expanded", String(!open));
  });
  links.addEventListener("click", (e)=>{
    if(e.target.closest("a")){
      nav.setAttribute("data-open","false");
      btn.setAttribute("aria-expanded","false");
    }
  });
}


document.addEventListener("DOMContentLoaded", ()=>{
  setupMenu();
  setupToggles();
  bindPricingTabs();
  setupButtons();
  loadData().then(()=>{ setupAnnounce();
    setupForms();
    setupCookie();
    setupFaqLinks();
    injectSchema();
  });
});
