
# Maestro · Sitio de Servicios (estático)

**Stack:** HTML5 + CSS moderno + JS (ES2023). Sin dependencias. Performance y accesibilidad (AA).

## Editables clave
- `assets/plans.json` → Precios, textos de planes, tasa USD (`usd_rate`), marca, slogan, contactos.
- Tema claro/oscuro y moneda se recuerdan en `localStorage`.
- Contrato PDF: `assets/contract-modelo.pdf` (generado desde plantilla).

## Deploy
- Abrí `index.html` en cualquier hosting estático (GitHub Pages, Netlify, Vercel Static, S3, etc.).

## Notas
- La tasa USD es meramente informativa.
- El plan Gratis requiere registro igual que planes pagos.
- Validaciones de formularios con Constraint Validation API + honeypot.
